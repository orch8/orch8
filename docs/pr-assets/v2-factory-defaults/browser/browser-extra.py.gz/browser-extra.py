import pathlib,json
from playwright.sync_api import sync_playwright,expect
out=pathlib.Path(__file__).parent;fixture=json.loads((out/'fixture.json').read_text());records=[];errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True)
 def new(path,mobile=False):
  page=b.new_page(viewport={'width':390 if mobile else 1440,'height':844 if mobile else 900});page.set_default_timeout(20000);page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:5173'+path);page.wait_for_load_state('networkidle');return page
 def shot(page,name):
  page.screenshot(path=str(out/(name+'.png')),timeout=20000);records.append({'name':name,'url':page.url,'text':page.locator('body').inner_text(),'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth'),'errors':errors.copy()});(out/'browser-extra.json').write_text(json.dumps(records,indent=2))
 page=new('/projects/factory-fixture/board',True);shot(page,'mobile-board');page.get_by_role('button',name='Toggle sidebar',exact=True).click();more=page.get_by_role('button',name='More',exact=True);more.focus();page.keyboard.press('Enter');expect(more).to_have_attribute('aria-expanded','true');shot(page,'mobile-more');page.get_by_role('link',name='Memory',exact=True).click();expect(page.get_by_role('dialog',name='Sidebar')).not_to_be_visible();expect(page).to_have_url('http://127.0.0.1:5173/projects/factory-fixture/memory');page.get_by_text('Compatibility decisions',exact=False).first.wait_for();shot(page,'mobile-memory-closed');page.close()
 for name,path in [('legacy-chat','/chat/'+fixture['chat']['id']),('legacy-memory','/memory'),('normal-agent-catalog','/agents/new'),('task-comments','/tasks/'+fixture['task']['id'])]:
  page=new('/projects/factory-fixture'+path);shot(page,name);page.close()
 page=new('/welcome');page.get_by_role('button',name='Next',exact=True).click();shot(page,'onboarding-project');page.get_by_placeholder('My App').fill('Quality preview');page.get_by_placeholder('/path/to/your/repo').fill('/tmp/orch8-factory-browser-quality-hK6OQuQo/preview');page.get_by_role('button',name='Next',exact=True).click();page.get_by_text('implementer',exact=True).first.wait_for();shot(page,'onboarding-agents');page.close()
 print(json.dumps({'captures':len(records),'errors':errors,'mobileDrawerClosed':True}));b.close()
