import json,pathlib
from playwright.sync_api import sync_playwright,expect
out=pathlib.Path(__file__).parent
fixture=json.loads(pathlib.Path('/tmp/orch8-factory-browser-quality-hK6OQuQo/fixture.json').read_text())
(out/'fixture.json').write_text(json.dumps(fixture,indent=2))
records=[];errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True)
 page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(15000)
 page.on('pageerror',lambda e:errors.append(str(e)))
 def shot(name):
  page.screenshot(path=str(out/(name+'.png')))
  records.append({'name':name,'url':page.url,'text':page.locator('body').inner_text(),'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth'),'errors':errors.copy()})
  (out/'browser.json').write_text(json.dumps(records,indent=2))
 def go(path):
  page.goto('http://127.0.0.1:5173'+path);page.wait_for_load_state('networkidle')
 go('/projects/factory-fixture');expect(page).to_have_url('http://127.0.0.1:5173/projects/factory-fixture/board');more=page.get_by_role('button',name='More',exact=True);expect(more).to_have_attribute('aria-expanded','false');shot('desktop-board')
 more.focus();page.keyboard.press('Enter');expect(more).to_have_attribute('aria-expanded','true');shot('desktop-more')
 toggles=page.get_by_role('button',name='Toggle sidebar',exact=True)
 print('TOGGLES',toggles.evaluate_all('(els)=>els.map(e=>({html:e.outerHTML,rect:e.getBoundingClientRect().toJSON()}))'),flush=True)
 visible=page.locator('button:visible').filter(has=page.locator('span',has_text='Toggle sidebar'))
 # Role selector restricted to visible elements avoids the hidden rail.
 toggle=page.locator('button:visible').and_(toggles).first
 expect(toggle).to_be_visible();toggle.click()
 expect(page.locator('[data-state="collapsed"][data-sidebar="sidebar"]').or_(page.locator('[data-state="collapsed"][data-slot="sidebar"]')).first).to_be_visible()
 more.focus();page.keyboard.press('Enter');expect(more).to_have_attribute('aria-expanded','false');shot('desktop-collapsed-closed')
 page.keyboard.press('Enter');expect(more).to_have_attribute('aria-expanded','true');shot('desktop-collapsed-more')
 go('/projects/factory-fixture/briefing');expect(more).to_have_attribute('data-active','true');expect(more).to_have_attribute('aria-expanded','true');shot('desktop-collapsed-active')
 toggle=page.locator('button:visible').and_(page.get_by_role('button',name='Toggle sidebar',exact=True)).first;toggle.click()
 for name,path in [('legacy-chat','/chat/'+fixture['chat']['id']),('legacy-memory','/memory'),('normal-agent-catalog','/agents/new'),('task-comments','/tasks/'+fixture['task']['id'])]:
  go('/projects/factory-fixture'+path);shot(name)
 go('/welcome');page.get_by_role('button',name='Next',exact=True).click();shot('onboarding-project')
 page.get_by_placeholder('My App').fill('Quality preview');page.get_by_placeholder('/path/to/your/repo').fill('/tmp/orch8-factory-browser-quality-hK6OQuQo/preview');page.get_by_role('button',name='Next',exact=True).click();page.get_by_text('implementer',exact=True).first.wait_for();shot('onboarding-agents')
 page.set_viewport_size({'width':390,'height':844});go('/projects/factory-fixture/board');shot('mobile-board')
 page.get_by_role('button',name='Toggle sidebar',exact=True).click();more=page.get_by_role('button',name='More',exact=True);more.focus();page.keyboard.press('Enter');expect(more).to_have_attribute('aria-expanded','true');shot('mobile-more')
 page.get_by_role('link',name='Memory',exact=True).click();expect(page.get_by_role('dialog',name='Sidebar')).not_to_be_visible();expect(page).to_have_url('http://127.0.0.1:5173/projects/factory-fixture/memory');page.get_by_text('Compatibility decisions',exact=False).first.wait_for();shot('mobile-memory-closed')
 print(json.dumps({'captures':len(records),'errors':errors,'mobileDrawerClosed':True,'collapsedKeyboard':True}));b.close()
