// Disposable review fixture. Run with HOME pointing at a new temporary directory.
import setup from "./src/__tests__/helpers/global-setup.js";
import { setupTestDb, teardownTestDb } from "./src/__tests__/helpers/test-db.js";
import { buildServer } from "./src/server.js";
import { SchedulerService } from "./src/services/scheduler.service.js";
import { chatMessages } from "@orch/shared/db";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";

if (!process.env.HOME?.startsWith("/tmp/orch8-factory-browser-")) throw new Error("Disposable HOME required");
SchedulerService.prototype.start = () => {};
const cleanup = await setup();
const db = await setupTestDb();
const app = buildServer({ databaseUrl: db.connectionUri, adminToken: "factory-fixture-token", spawnFn: () => { throw new Error("Provider execution forbidden"); } });
await app.initPromise;
const homeDir = join(process.env.HOME, "repository");
await mkdir(homeDir, { recursive: true });
await mkdir(join(process.env.HOME, ".orch8"), { recursive: true });
await writeFile(join(process.env.HOME, ".orch8/admin-token"), "factory-fixture-token");
const project = await app.projectService.create({ name: "Factory fixture", slug: "factory-fixture", key: "FAC", homeDir });
const chat = await app.chatService.createChat({ projectId: project.id, agentId: "chat", title: "Legacy discussion" });
await db.db.insert(chatMessages).values({ chatId: chat.id, role: "user", content: "Keep the existing API contract while simplifying setup." });
const memory = await app.memoryService.createEntity({ projectId: project.id, slug: "compatibility", name: "Compatibility decisions", entityType: "project", description: "Preserve existing conversations and task-local clarification." });
await app.memoryService.writeFact(memory.id, { content: "Legacy chat and memory remain available through More.", category: "decision" }, "user");
const task = await app.taskService.create({ projectId: project.id, title: "Preserve task-local clarification", description: "Confirm the existing API contract before implementation.", taskType: "quick", priority: "medium" });
await app.commentService.create({ taskId: task.id, author: "reviewer", body: "Should existing chat links keep working?", notify: false });
await writeFile(join(process.env.HOME, "fixture.json"), JSON.stringify({ project, chat, memory, task }, null, 2));
app.post("/fixture-shutdown", async (_request, reply) => {
  reply.send({ stopping: true });
  setImmediate(async () => {
    await app.close(); await teardownTestDb(db); await cleanup?.(); process.exit(0);
  });
});
await app.listen({ port: 3847, host: "127.0.0.1" });
console.log("FACTORY_FIXTURE_READY", process.env.HOME);
for (const signal of ["SIGTERM", "SIGINT"] as const) process.on(signal, async () => {
  await app.close(); await teardownTestDb(db); await cleanup?.(); process.exit(0);
});
