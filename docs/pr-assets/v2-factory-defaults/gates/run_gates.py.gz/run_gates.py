import datetime, hashlib, json, os, pathlib, subprocess, time
ROOT=pathlib.Path('/home/hermes/projects/orch8-factory-defaults')
OUT=pathlib.Path(__file__).parent
os.chdir(ROOT)
def git(*args): return subprocess.check_output(['git',*args])
def snapshot(label):
    names=git('ls-files','-z','--cached','--others','--exclude-standard').decode().split('\0')
    files={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(set(names)) if p and (ROOT/p).is_file()}
    data={'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'files':files,'manifest_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
    (OUT/f'source-{label}.json').write_text(json.dumps(data,indent=2)+'\n')
    (OUT/f'diff-{label}.patch').write_bytes(git('diff','HEAD','--binary'))
    (OUT/f'status-{label}.txt').write_bytes(git('status','--short'))
    return data
before=snapshot('before')
gates=[]
for package in ['shared','cli','daemon','dashboard']:
    gates.append((f'test-{package}', ['pnpm','--filter',f'@orch/{package}','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json',f'--outputFile={OUT/package}.json']))
gates += [('typecheck',['pnpm','exec','turbo','run','typecheck','--concurrency=1','--force']),('lint',['pnpm','lint']),('build',['pnpm','exec','turbo','run','build','--concurrency=1','--force'])]
results=[]
for name,cmd in gates:
    start=time.time()
    print('START',name,flush=True)
    with (OUT/f'{name}.log').open('w') as log:
        try:
            result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
            rc=result.returncode
        except subprocess.TimeoutExpired:
            rc=124
    row={'gate':name,'command':cmd,'cwd':str(ROOT),'started_at':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),'duration_seconds':round(time.time()-start,3),'exit_code':rc}
    results.append(row)
    (OUT/'gates.json').write_text(json.dumps(results,indent=2)+'\n')
    print('END',name,rc,flush=True)
after=snapshot('after')
print('SOURCE_UNCHANGED',before==after,flush=True)
