import collections,hashlib,json,pathlib,re,subprocess
out=pathlib.Path(__file__).parent
root=pathlib.Path('/home/hermes/projects/orch8-factory-defaults')
before=json.loads((out/'source-before.json').read_text())
names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
files={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(names)) if p and (root/p).is_file()}
assert files==before['files'], 'Source changed during verification'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==before['head']
results=[]
for package,report in [('shared','shared'),('cli','cli'),('daemon','daemon-tmpfs'),('dashboard','dashboard')]:
    data=json.loads((out/f'{report}.json').read_text())
    expected={str(root/p) for p in files if p.startswith(f'packages/{package}/') and re.search(r'\.(test|spec)\.[cm]?[jt]sx?$',p)}
    actual={t['name'] for t in data['testResults']}
    assert expected==actual,(package,expected-actual,actual-expected)
    assertions=[a for t in data['testResults'] for a in t['assertionResults']]
    assert data['success'] is True
    assert data['numFailedTestSuites']==0 and data['numFailedTests']==0
    assert data['numPendingTests']==0 and data['numTodoTests']==0
    assert data['numTotalTests']==data['numPassedTests']==len(assertions)>0
    assert all(t['status']=='passed' and not t.get('message') for t in data['testResults'])
    assert all(a['status']=='passed' and not a.get('failureMessages') for a in assertions)
    assert not data['snapshot']['failure']
    results.append({'package':package,'report':f'{report}.json','files':len(actual),'assertions':len(assertions),'passed':len(assertions),'all_source_test_files_present':True,'file_assertion_counts':{str(pathlib.Path(t['name']).relative_to(root)):len(t['assertionResults']) for t in data['testResults']}})
validation={'success':True,'source_unchanged':True,'manifest_sha256':before['manifest_sha256'],'total_files':sum(r['files'] for r in results),'total_assertions':sum(r['assertions'] for r in results),'packages':results}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
gates=json.loads((out/'gates.json').read_text())+[json.loads((out/'daemon-retry-gate.json').read_text())]
assert all(g['exit_code']==0 for g in gates)
lines=['# Factory-defaults final gates','', 'PASS for fresh tests, typecheck, lint and build on the source tree identified below. The first daemon attempt failed environmentally despite exit zero; its full retry passed. This report does not certify browser acceptance or authorize merge.','', '## Source binding','', f"- Worktree: `{root}`",f"- Branch: `{before['branch']}`",f"- HEAD: `{before['head']}`",f"- SHA-256 of sorted source-path/hash manifest: `{before['manifest_sha256']}`",'- `factory-reconciled/source-before.json` and `source-after.json` contain per-file SHA-256 hashes for all tracked and nonignored untracked files. They are identical. The validator checked the same hashes again after the daemon retry. Ignored build outputs are not part of this source manifest.','- Tracked patches and dirty status are preserved as `diff-before.patch`, `diff-after.patch`, `status-before.txt` and `status-after.txt`. No application or test sources were modified by this verification.','', '## Fresh full test results','', '| Package | Files | Assertions passed | Report |','| --- | ---: | ---: | --- |']
for r in results: lines.append(f"| {r['package']} | {r['files']} | {r['passed']}/{r['assertions']} | `{r['report']}` |")
lines += ['',f"Total: {validation['total_assertions']} passing assertions in {validation['total_files']} files across all four packages. Zero skipped, todo or failed assertions in the final reports. `validate.py` checks success flags, failed-suite counters, every file status and assertion status/failure message, snapshot status, aggregate counts and exact correspondence to all source test/spec files. `validation.json` records per-file assertion counts.",'','Tests ran directly through each package Vitest command instead of Turbo test caching. All gates ran serially and Vitest used one worker. Typecheck and build used `--force --concurrency=1` to execute uncached, serial package tasks.','', '## Commands and actual exits','', '| Gate | Exit | Seconds | Command |','| --- | ---: | ---: | --- |']
import shlex
for g in gates: lines.append(f"| {g['gate']} | {g['exit_code']} | {g['duration_seconds']} | `{shlex.join(g['command'])}` |")
lines += ['', 'Exact UTC starts, commands and subprocess return codes are in `gates.json` and `daemon-retry-gate.json`. Each gate has its own log. All paths in this report refer to `/home/hermes/orch8-evidence/factory-reconciled/` unless absolute.','', '## Failure preserved and resolved without code changes','', '- Initial `daemon.json` has `success:false`, 765 passed and eight skipped assertions, and one failed file. Its suite counter reports two failed suites. `test-daemon.log:1048-1064` shows PostgreSQL ENOSPC during pipeline-routes setup, followed by teardown reading `close` on an uninitialized app. The actual process exit was zero, reproducing the known false-green problem. This report does not count that attempt as passing.','- Filesystem inspection found the root filesystem at 100% usage with only 286 MiB available; `/dev/shm` had 1.9 GiB free. The retry used an isolated `TMPDIR=/dev/shm/factory-reconciled-z4u_al6u` so the existing test setup placed temporary PostgreSQL storage there. No shared files were deleted and no tests were weakened. The full daemon retry passed all 773 assertions in 97 files. The temporary directory was cleaned after execution.','- Typecheck completed all four tasks successfully with zero cached tasks, resolving the earlier ambiguous interrupted log. Lint exited zero with 66 warnings and zero errors. Build completed both defined tasks, CLI and dashboard, with zero cached tasks. Shared and daemon define no build script. Dashboard emitted a nonfatal chunk-size warning.','', '## Provenance and limits','', '- These reports supersede the stale dashboard 276/277 and ambiguous typecheck evidence for gate claims. Historical red reports remain untouched. The fresh dashboard result is 278/278, including the final mobile regression and Board redirect expectation.','- Browser/keyboard acceptance is owned by the concurrent reviewer and was not rerun here. This report makes no claim that those separate acceptance gaps are closed.','- No commits, pushes, merges, main-branch edits, source fixes or scope expansion were made. Build products and tooling caches were generated normally. Root filesystem capacity remains an environment risk for future runs using default `/tmp`.','']
pathlib.Path('/home/hermes/orch8-evidence/factory-defaults-final-gates.md').write_text('\n'.join(lines))
print(json.dumps({k:v for k,v in validation.items() if k!='packages'},indent=2))
print('Report written: /home/hermes/orch8-evidence/factory-defaults-final-gates.md')
