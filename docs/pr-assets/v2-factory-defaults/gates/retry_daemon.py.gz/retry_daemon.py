import datetime,json,os,pathlib,subprocess,tempfile,time
out=pathlib.Path(__file__).parent
root='/home/hermes/projects/orch8-factory-defaults'
cmd=['pnpm','--filter','@orch/daemon','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json',f'--outputFile={out}/daemon-tmpfs.json']
start=time.time()
with tempfile.TemporaryDirectory(prefix='factory-reconciled-',dir='/dev/shm') as tmp:
    env={**os.environ,'TMPDIR':tmp}
    with (out/'test-daemon-tmpfs.log').open('w') as log:
        p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    result={'gate':'test-daemon-tmpfs','command':cmd,'cwd':root,'environment_override':{'TMPDIR':tmp},'started_at':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),'duration_seconds':round(time.time()-start,3),'exit_code':p.returncode,'reason':'Original full daemon run encountered ENOSPC on root filesystem; retry with isolated RAM-backed temporary directory, no source changes.'}
    (out/'daemon-retry-gate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
