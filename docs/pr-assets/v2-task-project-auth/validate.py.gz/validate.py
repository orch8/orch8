import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

root = Path('/home/hermes/projects/orch8-task-project-auth')
evidence = Path('/home/hermes/orch8-evidence/task-project-auth')
summary = {}
for name in ['red', 'baseline-replay', 'green', 'green-final', 'compatibility', 'full']:
    data = json.loads((evidence / f'{name}.json').read_text())
    assertions = [a for s in data['testResults'] for a in s['assertionResults']]
    counts = Counter(a['status'] for a in assertions)
    assert len(assertions) == data['numTotalTests']
    assert counts['passed'] == data['numPassedTests']
    assert counts['failed'] == data['numFailedTests']
    assert counts['pending'] == data['numPendingTests']
    failures = [{ 'name': a['fullName'], 'message': a['failureMessages'][0].splitlines()[0]} for a in assertions if a['status'] == 'failed']
    summary[name] = {'success': data['success'], 'total': len(assertions), 'counts': dict(counts), 'failures': failures}
    if name not in ['red', 'baseline-replay']:
        assert data['success'] is True
        assert all(s['status'] == 'passed' and not s.get('message') for s in data['testResults'])
        assert counts['passed'] == len(assertions) > 0
    else:
        assert data['success'] is False
        assert any('unassigned pipeline task' in a['name'] and 'expected 200 to be 403' in a['message'] for a in failures)
files = ['packages/daemon/src/api/routes/tasks.ts', 'packages/daemon/src/api/utils/project-scope.ts', 'packages/daemon/src/__tests__/task-project-authorization.test.ts', 'packages/daemon/src/__tests__/project-scope.test.ts']
manifest = {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in files}
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
(evidence / 'validation.json').write_text(json.dumps({'base': base, 'results': summary, 'sourceSha256': manifest}, indent=2) + '\n')
print(json.dumps({'base': base, 'results': {k: {a: b for a, b in v.items() if a != 'failures'} for k, v in summary.items()}, 'sourceSha256': manifest}, indent=2))
