# Task-route project authorization

## Outcome and review gate

Implemented a narrow task-route authorization patch in `/home/hermes/projects/orch8-task-project-auth`, branch `fix/v2-task-project-auth`, based on `origin/v2` at `074a44e0b69cba6af83dd99717a71314ecc1d4e7`.

Changes are uncommitted and require independent security/specification review before commit, push or merge. No push, merge, deployment, main-tree edit, or atomic-progression worktree edit was performed. The original `/home/hermes/projects/orch8` worktree remained clean at final verification. The detached baseline evidence worktree is `/home/hermes/orch8-evidence/task-project-auth/baseline`.

## Exact production scope

Only `packages/daemon/src/api/routes/tasks.ts` and new `packages/daemon/src/api/utils/project-scope.ts` change production behavior.

- Authorize task ownership from the persisted task project against the authenticated agent's persisted project. Missing identity returns 401. Missing/inconsistent agent project context or foreign ownership returns generic 403. Missing resources return 404.
- Guard reads, deletes, metadata/column updates, transitions, quick/pipeline completion, dependency add/remove, conversion, checkout and release before their task-specific reads/responses or mutations. Completion checks scope before payload-specific handling and duplicate-completion results. Delete checks scope before execution/pipeline conflicts.
- Resolve create project ID/slug, then authorize before allocation. Validate agent-scoped assignee and dependency references before writes. Existing capabilities remain in place.
- Force token project into agent list filters, including malformed-filter fallback. Explicit foreign ID/slug filters return 403 even if another filter field is invalid.
- Preserve global admin task access regardless of selected project header and preserve admin association semantics. Checkout/release remain agent-only. Preserve same-project unassigned completion without run identity, verification gates, and existing create/move/assign capabilities and owner conflicts.
- No schema/migration, service method signature, scheduler, locking, completion state-machine, or task reparenting changes.

## Fixtures and regression coverage

New tests are `packages/daemon/src/__tests__/task-project-authorization.test.ts` and `packages/daemon/src/__tests__/project-scope.test.ts`.

Tests use real auth, Fastify `app.inject`, database-backed services, and isolated embedded PostgreSQL. Existing global setup starts a random temporary data directory and allocated port, migrates a template, and creates UUID fixture databases. No live application URLs or live project data were used. Localhost-admin fallback is explicitly disabled. The enqueue boundary is stubbed before requests so no real agents launch. The stub's return is unused by these routes.

The route suite covers every task-ID entrypoint, create project/reference denial, list fallback/explicit project denial, claimed header/query/body agent/run identity, immutable snapshots after denial, original single-step pipeline completion, successor-bearing completion, quick completion in a valid state, completed-pipeline foreign retry, same-project/admin CRUD and completion, verification gates, checkout/release owner rules, capability denials, and missing/invalid authentication. Snapshots include tasks, pipelines, steps, comments, dependencies and projects, including allocation counters. Forbidden dependency-removal tests seed actual cross-project edges in the isolated database. Helper tests cover absent/inconsistent project context and admin bypass.

The first test run exposed a fixture issue: startup rehydration rotates preinstalled token hashes and returned 401. Before implementing production changes, the fixture was corrected to install deterministic hashed tokens after `app.initPromise`. The retained valid RED then reproduced HTTP 200 versus expected 403. The initial pre-fix suite used a successor-bearing pipeline; final baseline replay additionally proves the exact single-step scenario fails on unchanged v2.

## Executed verification

All test commands used `VITEST_MAX_THREADS=2`, `pnpm --filter @orch/daemon exec vitest run`, JSON reporter, and output files under this evidence directory. The detached baseline ran `pnpm exec vitest` from its daemon directory, with symlinked installed dependencies and unchanged production v2 source.

| Evidence | Actual result |
| --- | --- |
| `red.json` before production edits | 35 assertions, 28 failed, 7 passed; inherited unassigned pipeline completion returned 200 instead of 403 |
| `baseline-replay.json` with final route tests against unchanged v2 | 36 assertions, 29 failed, 7 passed; both single-step and successor-bearing foreign completion fail |
| `green.json` initial targeted GREEN | 42 passed |
| `green-final.json` final targeted routes + helper | 43 passed |
| `compatibility.json` final targeted + auth + pipeline routes + lifecycle + tasks routes + task permissions integration | 113 passed |
| `full.json` final full daemon suite | 859 passed |
| `pnpm --filter @orch/daemon typecheck` | Exit 0 |
| `pnpm --filter @orch/daemon lint` | Exit 0, 9 warnings in unchanged daemon.ts, memory.ts, index.ts and memory-extraction.service.ts |
| `git diff --check` | Exit 0 |

`validate.py` parses the JSON reports and checks success flags, suite status/messages, every assertion status, and enumerated total/passed/failed/pending counts against reported totals. `validation.json` and `validation.log` retain the result. Shell exit alone was not accepted: failing RED runs also returned shell exit 0. The full run contains application diagnostic logs from other tests; JSON reports no failed assertions or suite errors. No claim is made that full-suite logs are pristine. An initial test stub `null` return caused a typecheck error; it was corrected to a typed test-only unused result before final verification.

## Source identity

HEAD/base is `074a44e0b69cba6af83dd99717a71314ecc1d4e7`. Final uncommitted source SHA-256:

| File | SHA-256 |
| --- | --- |
| `packages/daemon/src/api/routes/tasks.ts` | `af5b3ec0f837faceddc1b875313410972b9df89b48cadc529a64594ad343befa` |
| `packages/daemon/src/api/utils/project-scope.ts` | `eacc945378c75dc3e2d0627bcc0065b711a13515e78612417e8f7df63379c682` |
| `packages/daemon/src/__tests__/task-project-authorization.test.ts` | `56b10d34036c6720fddeb1708300c0ea91f23cd0f4593bea3847caa983cf27af` |
| `packages/daemon/src/__tests__/project-scope.test.ts` | `d5fbfe4900666e76a6b78d4463bb389557642f61520bc2778d25c728ac77a003` |

`production.diff` contains the tracked task-route diff; the helper and two new test files are untracked and identified by the hashes above. Review all four files, not only `git diff`.

## Explicit exclusions and remaining work

This is not complete tenant isolation.

- Pipeline routes remain a separately prioritized project-authorization gap and can indirectly affect task state. Existing admin-only approve/reject restrictions are not changed.
- Comment routes remain a separate task/project-authorization gap.
- Same-project transition body identity, unverified run headers, assignee/execution ownership policy, stale/exact-run protection and PATCH-column capability consistency remain outside this patch.
- Internal services remain trusted. No transactional service-level project authorization or reparenting protection was added. Future task reparenting or untrusted direct service entrypoints require a separate design.
- Allocator deadlocks, atomic progression locks, broadcasts, durable wakeup delivery and shutdown changes are excluded.
- Other route families were not exhaustively audited.

The inherited defect predates atomic progression. Independent review is still required; this implementer has not supplied independent approval. Reviewer should verify all four source hashes and perform guard-removal/inversion checks in a disposable copy. The unchanged-v2 replay provides negative-control evidence but does not replace independent review.
