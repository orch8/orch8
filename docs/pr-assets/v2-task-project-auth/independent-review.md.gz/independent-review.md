# Independent task-project authorization review

## Verdict

APPROVE the narrow task-route project authorization patch at the source hashes below. No blocking defect found within the agreed scope. This is not approval of complete tenant isolation or execution-identity security.

I independently read the implementation report and plan, all four changed/new files, authentication and permission middleware, project resolver, task schemas, task persistence and lifecycle services, and pipeline completion code. I reran isolated tests and inverted the project comparison in a disposable copy. I did not modify source in the reviewed worktree, commit, push, merge, or deploy.

Reviewed worktree: `/home/hermes/projects/orch8-task-project-auth`
Branch: `fix/v2-task-project-auth`
HEAD/base: `074a44e0b69cba6af83dd99717a71314ecc1d4e7`
The patch is uncommitted. Approval applies to these file contents, not to a future changed revision.

## Security and specification findings

- `project-scope.ts:10-20` permits global admins, requires agent identity otherwise, and fails closed for absent agent project, inconsistent request project, or foreign persisted ownership. Its foreign-project response is exactly `{ "error": "forbidden", "message": "Project access denied" }`.
- `auth.ts:53-65` derives both agent and project from the bearer-token database lookup. Header, query, task-ID prefix, transition body identity and run ID cannot override that scope. Authentication is an `onRequest` hook registered before task routes in `server.ts:294,359`. No-token and invalid-token requests fail before task handling.
- `tasks.ts:18-25` centralizes persisted task lookup and scope. Reads, deletion, PATCH metadata and column updates, explicit transitions, completion, dependency endpoints, conversion, checkout and release all pass through it before target-specific response or mutation. The table-driven tests use permissive capabilities, so their 403 results exercise project authorization, not an earlier capability denial.
- Completion checks scope at `tasks.ts:254-255`, before pipeline-vs-quick handling, output validation, pipeline lookup, duplicate results, comments, task transitions and wakeups. Both the original unassigned single-step case and a successor-bearing pipeline return generic 403 with unchanged task/pipeline/step/comment/dependency/project snapshots and no enqueue. Quick completion and foreign retry after legitimate completion are also covered.
- Delete checks scope before exposing execution-lock or pipeline conflict details. Checkout and release keep their earlier agent-required check, so an admin still gets 401 there. Existing same-project wrong-owner checkout and release behavior remains 409 and 403 respectively.
- Create resolves ID/slug and authorizes the target project before allocation. Agent assignee and initial dependency references are checked before task creation. PATCH checks the task first, then an explicit assignee. Dependency add/remove checks both parent and referenced task for agents. Actual forbidden edges are seeded for removal tests, including the reverse parent/target orientation. Denial snapshots include project allocation counters.
- Agent listing always receives the token project after parsing, including parse failure. A foreign explicit string project is checked independently of other invalid filters. `TaskService.list` combines project, assignee and pipeline filters with AND, so the latter cannot broaden the project restriction.
- Missing tasks and agent-scoped dependency references return 404. Missing assignee returns 404 by source inspection. Authentication still precedes resource existence checks. Existing capability prehandlers can deny before project lookup, and malformed create/PATCH input can return 400 before scope lookup. These responses reveal no persisted foreign task content and preserve the chosen ordering. Generic project 403 is not a promise that every malformed or capability-denied request receives the same response.
- Admin authorization ignores selected-project restrictions in the helper. Tested admin read, PATCH and completion succeed with another valid selected project. Admin CRUD and completion remain available, and admin association checks are deliberately bypassed. Existing auth behavior can still reject an invalid admin project header during project resolution; this patch does not change that behavior.

## Task-reference and compatibility review

No new caller-controlled task-route reference bypass was found within the agreed model. Create/PATCH schemas do not accept task reparenting or pipeline linkage fields. Pipeline and step references used by completion come from persisted task relationships, not completion payload fields. Assignee and dependency references supplied by agents are authorized before writes. Lifecycle unblocking is restricted to the authorized task's project in `task.service.ts:205-221`.

This conclusion assumes the existing trusted-service relationship model. The patch does not revalidate every historical or admin-created cross-project relationship. Admin cross-project association semantics are explicitly retained. Pipeline successor agent references are managed through the excluded pipeline APIs, not newly accepted through these task routes. `linkedIssueIds` remains external issue metadata stored on the task and forwarded into execution context, not a daemon task lookup in the inspected code. This review does not certify downstream external-tool authorization.

Fresh positive tests preserve same-project CRUD, column/explicit transitions, dependencies, conversion, unassigned quick and pipeline completion without a run header, duplicate completion and verification gating. Capability denial tests remain green. Global admin access and agent-only checkout/release remain distinct.

## Fresh executable evidence

All paths below are under `/home/hermes/orch8-evidence/task-project-auth/`.

Before running I inspected `helpers/global-setup.ts`, `helpers/test-db.ts`, and `vitest.config.ts`. Global setup starts embedded PostgreSQL in a random temporary directory on an allocated port, migrates a template and clones UUID fixture databases. No live database URI or production HTTP endpoint was used. The new route fixture disables localhost admin, awaits initialization before reinstalling token hashes, and stubs enqueue before requests.

1. `independent-tests.json` and `.log`: 78 passed, zero failed/pending/todo. Four files actually executed: auth 10, project-scope 7, task-project-authorization 36, tasks-routes 25.
2. `independent-compatibility.json` and `.log`: 35 passed, zero failed/pending/todo. Pipeline routes 14, lifecycle service 15, task permissions integration 6.
3. `independent-mutation.json` and `.log`: 43 enumerated tests, 26 failed and 17 passed, `success: false`. In a disposable copy only, changed `resourceProjectId !== request.agent.projectId` to `resourceProjectId === request.agent.projectId`. The exact single-step regression returned HTTP 200 instead of expected 403. The successor-bearing case also fails. The mutation is detected by the tests.
4. `independent-validation.json` records parsed assertion counts, actual suite filenames/statuses and mutation failure examples. For both green reports, required `success === true`, every file suite passed with empty message, no failed/runtime-error suites, every assertion passed, and enumerated passed/failed/pending/todo totals matching report totals. For the mutant required false success and actual failed assertions. Shell status was not used as the correctness gate: the mutant command returned zero despite 26 failures.

Commands were run from the reviewed repository, except the mutant command from the disposable daemon directory:

```sh
VITEST_MAX_THREADS=2 pnpm --filter @orch/daemon exec vitest run src/__tests__/task-project-authorization.test.ts src/__tests__/project-scope.test.ts src/__tests__/auth.test.ts src/__tests__/tasks-routes.test.ts src/__tests__/task-permissions.integration.test.ts --reporter=json --outputFile=/home/hermes/orch8-evidence/task-project-auth/independent-tests.json
VITEST_MAX_THREADS=2 pnpm --filter @orch/daemon exec vitest run src/__tests__/task-permissions-integration.test.ts src/__tests__/pipeline-routes.test.ts src/__tests__/task-lifecycle.service.test.ts --reporter=json --outputFile=/home/hermes/orch8-evidence/task-project-auth/independent-compatibility.json
VITEST_MAX_THREADS=2 pnpm exec vitest run src/__tests__/task-project-authorization.test.ts src/__tests__/project-scope.test.ts --reporter=json --outputFile=/home/hermes/orch8-evidence/task-project-auth/independent-mutation.json
```

The first command used an incorrect dotted permissions filename. JSON inspection exposed that it had not run; the second command explicitly ran the real hyphenated filename. There is no outstanding missing suite from the intended focused run. I did not independently rerun full-daemon tests, lint or typecheck, and do not adopt the implementer's full-suite results as fresh independent evidence.

## Non-blocking test improvements

Add explicit route assertions for foreign completion with malformed output, missing assignee, create via foreign slug, same-project UUID listing, and retained admin cross-project associations. The current guard placement and resolver code support the intended outcomes, but these exact variants are not directly covered by the new route tests. The positive helper test uses an empty reply stub, so inversion yields a TypeError for that one case rather than a clean boolean assertion failure; the foreign route failures still provide a genuine negative control.

## Source identity and unchanged worktree

SHA-256 values matched the implementation report before execution and matched again after execution:

| File under `packages/daemon/src/` | SHA-256 |
| --- | --- |
| `api/routes/tasks.ts` | `af5b3ec0f837faceddc1b875313410972b9df89b48cadc529a64594ad343befa` |
| `api/utils/project-scope.ts` | `eacc945378c75dc3e2d0627bcc0065b711a13515e78612417e8f7df63379c682` |
| `__tests__/task-project-authorization.test.ts` | `56b10d34036c6720fddeb1708300c0ea91f23cd0f4593bea3847caa983cf27af` |
| `__tests__/project-scope.test.ts` | `d5fbfe4900666e76a6b78d4463bb389557642f61520bc2778d25c728ac77a003` |

Final `git status --short` retained only the pre-existing modified tasks route and three untracked helper/test files. `git diff --check` exited zero. The disposable copy is `independent-mutation/`; its source is intentionally insecure and is evidence only, never a release candidate.

## Explicit exclusions

Pipeline and comment route project authorization remain open, including indirect task-state effects through pipeline routes. Same-project body identity impersonation, unverified run headers, execution/assignee ownership, stale/exact-run checks and PATCH-column capability consistency remain out of scope. Internal service callers are trusted. No transactional ownership guard or reparenting protection was added. Allocator deadlocks, atomic progression, locking, broadcasts, durable wakeups and shutdown behavior are not approved or changed by this review. Other route families were not exhaustively audited.
