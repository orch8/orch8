import collections, hashlib, json, os, pathlib, subprocess
root = pathlib.Path('/home/hermes/projects/orch8-pipeline-route-teardown')
out = pathlib.Path('/home/hermes/orch8-evidence/pipeline-route-teardown')
source = root / 'packages/daemon/src/__tests__/pipeline-routes.test.ts'
hash_before = hashlib.sha256(source.read_bytes()).hexdigest()
files = ['pipeline-routes.test.ts', 'async-work.test.ts', 'heartbeat.service.test.ts', 'pipeline-approval-safety.test.ts']
results = {}
def validate(path):
    data = json.loads(path.read_text())
    assertions = [a for f in data['testResults'] for a in f['assertionResults']]
    assert data['success'] is True
    assert data['numTotalTests'] == data['numPassedTests'] == len(assertions)
    assert data['numFailedTests'] == data['numPendingTests'] == data.get('numTodoTests', 0) == 0
    assert data['numFailedTestSuites'] == data['numPendingTestSuites'] == 0
    assert data['numPassedTestSuites'] == data['numTotalTestSuites']
    assert all(f['status'] == 'passed' and not f.get('message') for f in data['testResults'])
    assert all(a['status'] == 'passed' and not a.get('failureMessages') for a in assertions)
    return data, {'assertions': len(assertions), 'files': len(data['testResults']), 'suites': data['numTotalTestSuites']}
for i in range(1, 3):
    stem = f'independent-focused-{i}'
    report = out / (stem + '.json')
    assert not report.exists()
    cmd = ['node', 'node_modules/vitest/vitest.mjs', 'run', *['src/__tests__/' + f for f in files], '--no-file-parallelism', '--maxWorkers=1', '--reporter=json', '--outputFile=' + str(report)]
    with (out / (stem + '.log')).open('w') as log:
        proc = subprocess.run(cmd, cwd=root / 'packages/daemon', env={**os.environ, 'TMPDIR': '/dev/shm'}, stdout=log, stderr=subprocess.STDOUT)
    data, counts = validate(report)
    assert {pathlib.Path(f['name']).name for f in data['testResults']} == set(files)
    text = (out / (stem + '.log')).read_text()
    assert 'CONNECTION_ENDED' not in text
    errors, allowed = [], []
    for line in text.splitlines():
        try: record = json.loads(line)
        except ValueError: continue
        if not isinstance(record, dict) or record.get('level', 0) < 40: continue
        if record.get('code') == 'auth_denied' and record.get('httpStatus') == 401 and record.get('httpPath') in ['/api/pipelines/missing/steps/missing/approve', '/api/pipelines/missing/steps/missing/reject']:
            allowed.append(record)
        else: errors.append(record)
    assert not errors, errors
    route = next(f for f in data['testResults'] if f['name'].endswith('/pipeline-routes.test.ts'))
    assert len(route['assertionResults']) == 14
    results[stem] = {**counts, 'returncode': proc.returncode, 'command': cmd, 'allowed_auth_warnings': len(allowed), 'unexpected_diagnostics': errors, 'route_tests': [a['fullName'] for a in route['assertionResults']]}
    assert hashlib.sha256(source.read_bytes()).hexdigest() == hash_before
_, results['archived_full_daemon'] = validate(out / 'full-daemon.json')
base = subprocess.check_output(['git', 'show', '7fcfac8:packages/daemon/src/__tests__/pipeline-routes.test.ts'], cwd=root, text=True)
current = source.read_text()
expectations = lambda s: collections.Counter(l.strip() for l in s.splitlines() if 'expect(' in l)
assert not expectations(base) - expectations(current)
assert base[base.index('  describe("Pipeline Templates"'):].rstrip() == current[current.index('  describe("Pipeline Templates"'):].rstrip()
results['original_test_bodies_identical'] = True
results['preserved_expectation_lines'] = sum(expectations(base).values())
results['source_sha256'] = hash_before
results['changed_tracked_files'] = subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=root, text=True).splitlines()
assert results['changed_tracked_files'] == ['packages/daemon/src/__tests__/pipeline-routes.test.ts']
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
(out / 'independent-validation.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
