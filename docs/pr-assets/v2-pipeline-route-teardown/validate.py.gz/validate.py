import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/home/hermes/projects/orch8-pipeline-route-teardown')
CWD = ROOT / 'packages/daemon'
OUT = Path('/home/hermes/orch8-evidence/pipeline-route-teardown')
SOURCE = CWD / 'src/__tests__/pipeline-routes.test.ts'
FILES = ['pipeline-routes.test.ts', 'async-work.test.ts', 'heartbeat.service.test.ts', 'pipeline-approval-safety.test.ts']

def digest():
    return hashlib.sha256(SOURCE.read_bytes()).hexdigest()

def validate(path):
    report = json.loads(path.read_text())
    tests = [t for f in report['testResults'] for t in f['assertionResults']]
    assert report['success'] is True
    assert report['numFailedTests'] == report['numPendingTests'] == 0
    assert report['numPassedTests'] == len(tests)
    assert all(t['status'] == 'passed' for t in tests)
    assert all(f['status'] == 'passed' for f in report['testResults'])
    return {'tests': len(tests), 'files': len(report['testResults'])}

before = digest()
results = {}
for n in range(1, 4):
    name = f'focused-final-{n}'
    report = OUT / f'{name}.json'
    assert not report.exists(), report
    command = ['node', 'node_modules/vitest/vitest.mjs', 'run', *['src/__tests__/' + f for f in FILES], '--no-file-parallelism', '--maxWorkers=1', '--reporter=json', '--outputFile=' + str(report)]
    with (OUT / f'{name}.log').open('w') as log:
        proc = subprocess.run(command, cwd=CWD, env={**os.environ, 'TMPDIR': '/dev/shm'}, stdout=log, stderr=subprocess.STDOUT)
    result = validate(report)
    raw = json.loads(report.read_text())
    assert {Path(f['name']).name for f in raw['testResults']} == set(FILES)
    logs = (OUT / f'{name}.log').read_text()
    assert 'CONNECTION_ENDED' not in logs
    errors = []
    for line in logs.splitlines():
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if isinstance(record, dict) and record.get('level', 0) >= 40:
            # Approval-safety deliberately rejects unauthenticated approve/reject requests.
            if (record.get('code') == 'auth_denied' and record.get('httpStatus') == 401
                    and record.get('httpPath') in ['/api/pipelines/missing/steps/missing/approve', '/api/pipelines/missing/steps/missing/reject']):
                continue
            errors.append(record)
    assert not errors, errors
    results[name] = {**result, 'exit': proc.returncode, 'commands': command, 'unexpected_service_logs': errors}
    assert digest() == before
results['full-daemon'] = validate(OUT / 'full-daemon.json')
original = subprocess.check_output(['git', 'show', '7fcfac8:packages/daemon/src/__tests__/pipeline-routes.test.ts'], cwd=ROOT, text=True)
expectations = lambda text: collections.Counter(l.strip() for l in text.splitlines() if 'expect(' in l)
missing = expectations(original) - expectations(SOURCE.read_text())
assert not missing, missing
results['original_expectation_lines'] = sum(expectations(original).values())
results['source_sha256'] = before
results['assertions_preserved'] = True
(OUT / 'validation.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
