# Independent pipeline-route teardown review

## Verdict

- Spec compliance: PASS for the requested test-fixture teardown repair.
- Code quality: PASS. No blocking findings in the changed source.
- Scope: only `packages/daemon/src/__tests__/pipeline-routes.test.ts` differs from HEAD. No production or shared-helper changes. No source edits, staging, commits, pushes, or merges performed during this review. The three untracked dependency links remain excluded.

Reviewed worktree `/home/hermes/projects/orch8-pipeline-route-teardown`, branch `fix/v2-pipeline-route-teardown`, HEAD/base `7fcfac870bb3e40a7d7d9e9d4400207c45448998`.

Source SHA-256 before and after fresh tests:

`fcc3ceaf06d9807f8ad5238d1b0295a5e208090064dc3804b9496fa1a2e02fcf`

## Lifecycle and regression review

The owner is installed before readiness awaits. Each test awaits both Fastify readiness and `initPromise`. The previous owner is cleaned before task/pipeline table deletion. `cleanupFixture` stops scheduler timers, then delegates gate release, complete execution-promise draining, interception restoration, and app closure to the unchanged `createAsyncWork` helper. Its pending loop joins executions recursively launched by final queue promotion. Restoration and app closure remain in nested finally blocks if draining rejects. Database teardown is in the outer afterAll finally.

This addresses the actual production execution boundary: heartbeat.service.ts awaits final queue promotion at lines 1000-1004, after terminal persistence and lock cleanup. A successful route response or persisted terminal row alone is insufficient.

All six added regressions pass independently:

1. Successful final queue promotion stays held until cleanup releases it.
2. An assertion throws before gate release, yet cleanup drains and closes resources.
3. Final queue work rejects, cleanup still restores/closes, and a subsequent drain explicitly checks the queue-launcher's expected error diagnostic.
4. A logger error is surfaced by cleanup.
5. An errorLogger record is surfaced by cleanup.
6. Real lock cleanup fails inside the service's finally block while executeRun fulfills and the stored run succeeds with finishedAt. The attached observers make cleanup reject with `lock_release_failed`, while app and SQL closure still occur.

The five gated cases inspect zero pending promises, completed queue promotion, and restored executeRun interception at the actual close call. They also verify the app and SQL client reject subsequent work. The swallowed-error test is materially stronger than synthetic promise rejection because it exercises the real catch-and-log path.

Programmatic comparison confirms all eight original test bodies are identical to the base commit, not merely equivalent assertion counts. All 21 original expectation-bearing lines are preserved. No skipped tests or weakened assertions were introduced. Added lines contain no credentials, unsafe dynamic execution, or raw SQL interpolation.

## Fresh execution evidence

Ran two new focused executions from `packages/daemon`, with `TMPDIR=/dev/shm`:

```text
node node_modules/vitest/vitest.mjs run src/__tests__/pipeline-routes.test.ts src/__tests__/async-work.test.ts src/__tests__/heartbeat.service.test.ts src/__tests__/pipeline-approval-safety.test.ts --no-file-parallelism --maxWorkers=1 --reporter=json --outputFile=<independent-focused-N.json>
```

Each run produced 83 passed assertions across the exact four requested files and 20 reported suites. All 14 route tests passed, including the six regressions. Failed, pending, and todo counts were zero. The validator checked success, total/passed count equality, suite counts, every file status, every assertion status, empty failure messages, and exact file coverage. Both child processes returned zero, but approval is based on those JSON checks, not exit status.

Both logs contain zero CONNECTION_ENDED occurrences and no unexpected structured warning/error records. Each contains exactly the two intentional approval-safety auth_denied warnings for the missing approve/reject endpoints.

Fresh `node node_modules/typescript/bin/tsc --noEmit` returned zero with no output. `git diff --check` passed. Source hash and tracked-file scope remained unchanged.

Artifacts created by this reviewer:

- `independent-validate.py`
- `independent-validation.json`
- `independent-focused-1.json` and `independent-focused-1.log`
- `independent-focused-2.json` and `independent-focused-2.log`
- `independent-review.md`

## Archived evidence and limitations

Independently parsed existing baseline and negative reports. Baseline has eight passing assertions. `red2.json` has five failed gated regressions and eight filtered/skipped originals. Its failures occur in real final queue database queries. `observer-negative.json` has one failed swallowed-error regression and 13 filtered/skipped tests, with the intended failure that cleanup resolved instead of rejecting. These support regression sensitivity. I did not rerun mutations or modify source to reproduce them.

Independently validated archived `full-daemon.json`: 816 passed assertions, 99 files, 372 reported suites, zero failed/pending assertions or suites, and all file/assertion statuses passed. This was an existing execution, not a fresh full-suite rerun.

The full suite is NOT diagnostically clean. I checked the raw `full-daemon.log` and confirmed the four startup diagnostics documented in `full-log-analysis.json`: three missing-relation errors involving heartbeat_runs, agents, and chat_messages, and one skill-sync CONNECTION_ENDED error. The archived analysis associates them with startup.test.ts and integration.test.ts. Those diagnostics do not appear in the fresh focused runs and are not repaired by this test-only change. Temporal association does not prove all root causes.

Approval covers this route fixture's execution teardown, not a production-wide shutdown guarantee. In particular, stopping scheduler timers is not a general join for an already-running scheduler tick, and initPromise does not include every fire-and-forget startup operation. The patch neither changes nor claims to repair those production contracts. No setup-readiness-failure injection was added or independently exercised; ownership-before-await and finally cleanup were reviewed statically.
