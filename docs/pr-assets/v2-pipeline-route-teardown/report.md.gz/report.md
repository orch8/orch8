# Pipeline route teardown repair

## Result

Implemented a test-only repair on fresh branch `fix/v2-pipeline-route-teardown` in `/home/hermes/projects/orch8-pipeline-route-teardown`, based on v2 `7fcfac870bb3e40a7d7d9e9d4400207c45448998`.

Only repository source change: `packages/daemon/src/__tests__/pipeline-routes.test.ts`. No production changes, helper changes, weakened assertions, skipped tests, pushes, merges, or changes to the v2 checkout. The three untracked node_modules symlinks point to existing dependencies and must not be staged. The source change is uncommitted for parent-agent independent review. This subagent has no delegate_task tool and cannot supply independent approval of its own patch.

## Reproduction and cause

Read the independent heartbeat review and its standalone route log. A fresh baseline standalone route run reproduced all eight passing tests alongside four CONNECTION_ENDED error records, including failed task-lock cleanup, failed ErrorLogger database persistence, and unhandled executeRun final queue promotion. See `baseline.json` and `baseline.log`.

The fixture awaited app.close, whose hooks close the server SQL client, without joining route-triggered executeRun promises. Terminal status and route response completion do not include the final lock cleanup and queue promotion. Deleting tasks in the next beforeEach also lacked an execution barrier.

Ranked hypotheses were unfinished execution at close, work crossing row reset, and unrelated startup work. The original isolated run confirms the first without loading heartbeat tests. Holding final queue promotion confirms that the close boundary, not terminal-state polling, must own the promise. Per-test app ownership exposed a separate startup initialization race during development; awaiting the existing app.initPromise resolves that fixture initialization requirement without changing production startup.

## Changes and coverage

- Keep the same project and agent IDs and database. Give each test an app owner, installed before awaiting readiness. Await both app.ready and app.initPromise.
- Reuse createAsyncWork unchanged to track the owning heartbeat service's executeRun, release gates, drain recursively launched work, restore interception in finally, and close the owning app even on rejection.
- Stop the scheduler before cleanup. beforeEach joins any prior owner before row deletion. afterEach and afterAll share cleanup; database teardown remains in finally.
- Attach the helper's logger and errorLogger observers to the actual service, so swallowed cleanup diagnostics fail the fixture rather than disappearing behind fulfilled promises.
- Preserve all 21 original expectation-bearing lines, checked as a multiset against the base commit. All eight original route tests remain.
- Add five gated final-queue regressions for success, assertion failure before gate release, rejected queue work, logger error, and errorLogger record. At the actual app.close call, assert zero pending work, completed queue promotion, and restored executeRun identity. Also assert actual Fastify rejection after close and SQL-client rejection after close.
- Add a real swallowed cleanup-error regression. A successful execution encounters an injected releaseTaskLock rejection in its real finally block. executeRun still fulfills and the persisted run is succeeded with finishedAt, but fixture cleanup must reject with lock_release_failed and still close app/SQL resources.
- The rejected-queue case explicitly checks its expected launcher diagnostic with a second drain. The helper reports the rejected promise before checking recorded diagnostics, so this deliberate error must not be silently discarded.

## Red and negative evidence

`red2.json` records all five gated regressions failing with the close-without-drain implementation. Real final queue queries hit CONNECTION_ENDED. Their fallback cleanup releases gates and restores spies even after failure. The earlier `red.json` was an invalid gate placement that also held the initial enqueue promotion; it is retained as development history, not accepted red evidence.

`observer-negative.json` records the swallowed-error regression failing when both observers are disconnected. It reaches the intended assertion: cleanup resolved instead of rejecting. The raw log shows the actual injected lock cleanup error. Both temporary disconnections were restored in finally. Filtered negative runs intentionally leave unrelated tests pending; final runs do not.

`green1.json` records a development failure from an unconsumed expected rejection diagnostic during a second cleanup. This led to explicitly asserting that diagnostic. `green2.json` has 14 passing route tests.

## Verification

Commands run from the worktree's packages/daemon directory with TMPDIR=/dev/shm. Vitest was invoked directly with Node, JSON reporting, --no-file-parallelism and --maxWorkers=1. JSON status, every assertion status, file coverage, and totals were validated rather than trusting shell exit. Negative reports returned exit zero despite failure, consistent with the existing Vitest exit issue.

`validate.py` runs the final focused command three times and checks source hash stability, exact requested file coverage, preserved original assertions, no failed or pending tests, no CONNECTION_ENDED, and no unexpected structured warning/error logs. It explicitly allows only the two known approval-safety auth_denied requests for missing approve/reject endpoints.

- `focused-final-1.json`, `focused-final-2.json`, `focused-final-3.json`: each 83 passed, four files, zero failed or pending. Files are pipeline-routes, async-work, heartbeat.service, and pipeline-approval-safety. No unexpected service logs.
- `full-daemon.json`: 816 passed across 99 files, zero failed or pending. All assertion and file statuses checked. The full run preceded only trailing-blank-line removal; all behavioral code matches final source.
- `node node_modules/typescript/bin/tsc --noEmit`: exit zero, empty `typecheck.log`.
- `git diff --check`: clean after removing trailing blank lines.
- Final source SHA-256: `fcc3ceaf06d9807f8ad5238d1b0295a5e208090064dc3804b9496fa1a2e02fcf`.

The first focused-log validation stopped on expected approval-safety authentication warnings. Its report/log remain as `focused-1.*`. The validator was narrowed to explicitly allow only those intentional rejection records, and all three final runs passed.

## Full-suite log limits

Do not describe the entire daemon suite as free of asynchronous errors. `full-log-analysis.json` records three missing-relation startup diagnostics overlapping startup.test.ts and one CONNECTION_ENDED skill-sync startup diagnostic 13 ms after integration.test.ts ended. These are outside this route fixture and were not changed. No route-agent cleanup or unhandled executeRun errors appeared in the final focused logs. Passing JSON alone is not proof of globally quiet background work.

## Review status

Self-review found no production changes, secrets, dynamic execution, weakened original expectations, or unsafe query construction. Independent review and commit remain for the parent agent. The requested repair and execution evidence are complete locally; no claim of independent approval or production shutdown repair is made.
